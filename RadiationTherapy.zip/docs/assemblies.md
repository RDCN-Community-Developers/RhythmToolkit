## [返回](../RadiationTherapy.md)

# 主要程序集

程序集名 | 程序集主要功能
-|-
[RhythmBase](assembly/RhythmBase.md)| 核心
[RhythmBase.Animation](assembly/RhythmAnimation.md) | 动画模块扩展

# 其他程序集

程序集名 | 程序集主要功能
-|-
RhythmBase.Addition | 辅助工具扩展
RhythmHospital | 合法性检查扩展