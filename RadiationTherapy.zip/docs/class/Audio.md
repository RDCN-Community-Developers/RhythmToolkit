# [RhythmBase](../../RhythmToolkit.md).[Components](../namespace/Components.md).Audio
### [RhythmBase.dll](../assembly/RhythmBase.md)
音频。

## 属性和字段

修饰 | 类型 | 名称 | 说明
-|-|-|-
| | string | Filename | 音频名称。
| | int | Volume | 音量。
| | int | Pitch | 音高。
| | int | Pan | 声像。
| | int | Offset | 音效偏移。