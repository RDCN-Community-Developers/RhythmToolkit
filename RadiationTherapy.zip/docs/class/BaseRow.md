# BaseBeatsPerMinute  
BPM事件的基类，继承自[BaseEvent](BaseEvent.md)。所有BPM事件都直接继承于此。  
此类必需被继承。  

## 属性和字段

修饰 | 类型 | 名称 | 说明
-|-|-|-
| | float | BeatsPerMinute | BPM值。  