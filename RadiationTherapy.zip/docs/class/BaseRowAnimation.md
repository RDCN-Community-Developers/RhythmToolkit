# [RhythmBase](../../RhythmToolkit.md).[Events](../namespace/Events.md).BaseRowAnimation  
### [RhythmBase.dll](../assembly/RhythmBase.md)
轨道动画事件的基类，继承自[BaseRowAction](BaseEvent.md)。所有轨道动画事件都直接继承于此。  
此类必需被继承。  
