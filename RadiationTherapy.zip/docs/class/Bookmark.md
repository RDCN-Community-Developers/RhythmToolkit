# [RhythmBase](../../RhythmToolkit.md).[LevelElements](../namespace/LevelElements.md).Bookmark
### [RhythmBase.dll](../assembly/RhythmBase.md)
时间轴标签。  

## 属性和字段

修饰 | 类型 | 名称 | 说明
-|-|-|-
| | uint | Bar | 小节。
| | uint | Beat | 节拍。
| | [BookmarkColors](../enum/Bookmark.Colors.md) | Color | 标签颜色。