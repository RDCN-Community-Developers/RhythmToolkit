# [RhythmBase](../../RhythmToolkit.md).[LevelElements](../namespace/LevelElements.md).Condition  
### [RhythmBase.dll](../assembly/RhythmBase.md)
条件。  
作为关卡事件的 `If` 属性。

## 属性和字段

修饰 | 类型 | 名称 | 说明
-|-|-|-
| | List\<(bool Enabled, [BaseConditional](../class/BaseConditional.md) Conditional)\> | ConditionLists | 条件的启用/禁用列表。
| | float | Duration | 条件的持续时间。