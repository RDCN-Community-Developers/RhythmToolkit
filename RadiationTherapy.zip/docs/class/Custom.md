# [RhythmBase](../namespaces.md).[LevelElements](../namespace/LevelElements.md).[Conditions](../namespace/Conditions.md).Custom
### [RhythmBase.dll](../assembly/RhythmBase.md)
自定义条件。  
继承 [BaseConditional](../class/BaseConditional.md) 。

## 属性和字段

修饰 | 类型 | 名称 | 说明
-|-|-|-
readonly | [ConditionalType](../enum/ConditionalType.md) | Type | 返回条件类型 [ConditionalType](../enum/ConditionalType.md).Custom 。
| | string | Expression | 返回或设置条件判定表达式。