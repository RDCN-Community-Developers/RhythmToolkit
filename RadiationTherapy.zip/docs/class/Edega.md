# [RhythmHospital](../namespaces.md).[Physicians](../namespace/Physicians.md).SpriteInputSettings

修饰 | 类型 | 名称 | 说明
-|-|-|-
static | | DetectingAll([RDLevel](../class/RDLevel.md) level) | 检查关卡节拍的合法性(待开发)。