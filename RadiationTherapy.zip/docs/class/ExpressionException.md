# [RhythmBase](../namespaces.md).[Exceptions](../namespace/Exceptions.md).ExpressionException
### [RhythmBase.Animation.dll](../assembly/RhythmAnimation.md)
表达式异常。  
继承自 `Exception` 类。