# [RhythmBase](../namespaces.md).[Exceptions](../namespace/Exceptions.md).FileExtensionMismatchException
文件后缀异常。  
继承自 `SpriteException` 类。