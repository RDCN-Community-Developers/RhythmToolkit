# [RhythmBase](../namespaces.md).[LevelElements](../namespace/LevelElements.md).[Conditions](../namespace/Conditions.md).LastHit
### [RhythmBase.dll](../assembly/RhythmBase.md)
最后一拍。  
继承 [BaseConditional](../class/BaseConditional.md) 。

## 枚举

- [HitResult](../enum/LastHit.HitResult.md)

## 属性和字段

修饰 | 类型 | 名称 | 说明
-|-|-|-
readonly | [ConditionalType](../enum/ConditionalType.md) | Type | 返回条件类型 [ConditionalType](../enum/ConditionalType.md).LastHit 。
| | sbyte | Row | 返回或设置条件监测的轨道序号。
| | [HitResult](../enum/LastHit.HitResult.md) | Result | 返回或设置条件执行所需参数。