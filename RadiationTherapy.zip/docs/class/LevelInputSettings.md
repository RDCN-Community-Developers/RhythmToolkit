# [RhythmBase](../namespaces.md).[Settings](../namespace/Settings.md).LevelInputSettings
### [RhythmBase.dll](../assembly/RhythmBase.md)

## 属性和字段

修饰 | 类型 | 名称 | 说明
-|-|-|-
| | bool | UsingIdFromFile | 返回或设置是否使用关卡文件内的 ID