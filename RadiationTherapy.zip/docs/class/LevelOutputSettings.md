# [RhythmBase](../namespaces.md).[Settings](../namespace/Settings.md).LevelInputSettings
### [RhythmBase.dll](../assembly/RhythmBase.md)