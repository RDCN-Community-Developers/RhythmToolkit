# [RhythmBase](../namespaces.md).[Exceptions](../namespace/Exceptions.md).ModuleException
### [RhythmBase.dll](../assembly/RhythmBase.md)
模块异常。  
继承自 `RhythmBaseException` 类。