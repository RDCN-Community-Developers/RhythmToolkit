# [RhythmBase](../namespaces.md).[Exceptions](../namespace/Exceptions.md).OverwriteNotAllowedException
覆写不允许异常。  
继承自 `SpriteException` 类。