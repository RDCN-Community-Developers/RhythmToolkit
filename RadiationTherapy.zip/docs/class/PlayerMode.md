# [RhythmBase](../namespaces.md).[LevelElements](../namespace/LevelElements.md).[Conditions](../namespace/Conditions.md).PlayerMode
### [RhythmBase.dll](../assembly/RhythmBase.md)
游玩模式。  
继承 [BaseConditional](../class/BaseConditional.md) 。