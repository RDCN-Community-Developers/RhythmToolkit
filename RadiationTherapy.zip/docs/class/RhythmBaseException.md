# [RhythmBase](../namespaces.md).[Exceptions](../namespace/Exceptions.md).RhythmBaseException
### [RhythmBase.dll](../assembly/RhythmBase.md)
关卡内部异常。  
继承自 `Exception` 类。