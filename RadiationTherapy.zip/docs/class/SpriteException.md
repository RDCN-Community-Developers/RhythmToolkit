# [RhythmBase](../namespaces.md).[Exceptions](../namespace/Exceptions.md).SpriteException
精灵异常。  
继承自 `Exception` 类。