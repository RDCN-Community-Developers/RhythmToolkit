# [RhythmBase](../namespaces.md).[Settings](../namespace/Settings.md).SpriteOutputSettings
### [RhythmBase.dll](../assembly/RhythmBase.md)