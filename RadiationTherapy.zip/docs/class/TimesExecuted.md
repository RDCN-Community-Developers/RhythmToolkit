# [RhythmBase](../namespaces.md).[LevelElements](../namespace/LevelElements.md).[Conditions](../namespace/Conditions.md).TimesExecuted
### [RhythmBase.dll](../assembly/RhythmBase.md)
执行次数。  
继承 [BaseConditional](../class/BaseConditional.md) 。

## 属性和字段

修饰 | 类型 | 名称 | 说明
-|-|-|-
readonly | [ConditionalType](../enum/ConditionalType.md) | Type | 返回条件类型 [ConditionalType](../enum/ConditionalType.md).TimesExecuted 。
| | int | MaxTimes | 返回或设置条件执行的最大次数。