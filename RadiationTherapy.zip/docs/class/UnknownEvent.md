# [RhythmBase](../../RhythmToolkit.md).[Events](../namespace/Events.md).CustomEvent  
### [RhythmBase.dll](../assembly/RhythmBase.md)
未知事件，继承自[BaseEvent](BaseEvent.md)。

## 属性和字段

修饰 | 类型 | 名称 | 说明
-|-|-|-
readonly | string | RealType | 返回表示此事件实际的类型的字符串。  
| | JObject | Data | 此未知事件的所有数据。