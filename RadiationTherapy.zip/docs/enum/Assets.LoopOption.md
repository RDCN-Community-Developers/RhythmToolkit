# [RhythmBase](../namespaces.md).[Utils](../namespace/Utils.md).LoopOption
### [RhythmBase.dll](../assembly/RhythmBase.md)

- no
- yes
- onBeat