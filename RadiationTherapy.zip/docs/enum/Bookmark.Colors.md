# [RhythmBase](../../RhythmToolkit.md).[LevelElements](../namespace/LevelElements.md).[Bookmark](../class/Bookmark.md).Colors

- Blue
- Red
- Yellow
- Green