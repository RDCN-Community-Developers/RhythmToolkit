# [RhythmBase](../../RhythmToolkit.md).[LevelElements](../namespace/LevelElements.md).[BaseConditional](../class/BaseConditional.md).ConditionalType

- LastHit
- Custom
- TimesExecuted
- Language
- PlayerMode