# [RhythmBase](../namespaces.md).[LevelElements](../namespace/LevelElements.md).[Conditions](../namespace/Conditions.md).[LastHit](../class/LastHit.md).HitResult

 Perfect = 0
 SlightlyEarly = 2
 SlightlyLate = 3
 VeryEarly = 4
 VeryLate = 5
 AnyEarlyOrLate = 7
 Missed = 15