# [RhythmBase](../namespaces.md).[LevelElements](../namespace/LevelElements.md).[Conditions](../namespace/Conditions.md).[Language](../class/Language.md).Languages

- English
- Spanish
- Portuguese
- ChineseSimplified
- ChineseTraditional
- Korean
- Polish
- Japanese
- German