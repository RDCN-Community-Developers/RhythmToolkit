# [RhythmBase](../../RhythmToolkit.md).[Events](../namespace/Events.md).PlayerType
### [RhythmBase.dll](../assembly/RhythmBase.md)

- P1
- P2
- CPU
- NoChange