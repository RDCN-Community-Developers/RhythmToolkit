# [RhythmBase](../../RhythmToolkit.md).[LevelElements](../namespace/LevelElements.md).[Row](../class/Row.md).PlayerMode

- P1
- P2
- CPU