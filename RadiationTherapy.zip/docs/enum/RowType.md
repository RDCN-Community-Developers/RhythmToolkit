# [RhythmBase](../../RhythmToolkit.md).[Events](../namespace/Events.md).RowType
### [RhythmBase.dll](../assembly/RhythmBase.md)

- Classic
- Oneshot