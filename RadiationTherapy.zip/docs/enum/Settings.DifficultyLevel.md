# [RhythmBase](../../RhythmToolkit.md).[LevelElements](../namespace/LevelElements.md).[Settings](../class/Settings.md).DifficultyLevel

- Easy
- Medium
- Tough
- VeryTough