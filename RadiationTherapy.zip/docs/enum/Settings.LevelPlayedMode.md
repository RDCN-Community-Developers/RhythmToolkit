# [RhythmBase](../../RhythmToolkit.md).[LevelElements](../namespace/LevelElements.md).[Settings](../class/Settings.md).LevelPlayedMode

- OnePlayerOnly
- TwoPlayerOnly
- BothModes