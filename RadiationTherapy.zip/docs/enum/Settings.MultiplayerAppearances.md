# [RhythmBase](../../RhythmToolkit.md).[LevelElements](../namespace/LevelElements.md).[Settings](../class/Settings.md).MultiplayerAppearances

- HorizontalStrips