# [RhythmBase](../../RhythmToolkit.md).[LevelElements](../namespace/LevelElements.md).[Settings](../class/Settings.md).SpecialArtistTypes

- None
- AuthorIsArtist
- PublicLicense