# [RhythmBase](../../RhythmToolkit.md).[Components](../namespace/Components.md).[SoundSubType](../class/SoundSubType.md).GroupSubtypes

- ClapSoundHoldLongEnd
- ClapSoundHoldLongStart
- ClapSoundHoldShortEnd
- ClapSoundHoldShortStart
- FreezeshotSoundCueLow
- FreezeshotSoundCueHigh
- FreezeshotSoundRiser
- FreezeshotSoundCymbal
- BurnshotSoundCueLow
- BurnshotSoundCueHigh
- BurnshotSoundRiser
- BurnshotSoundCymbal