# [RhythmBase](../namespaces.md).[Settings](../namespace/Settings.md).[SpriteInputSettings](../class/SpriteInputSettings.md).OutputModes

- HORIZONTAL
- VERTICAL
- PACKED