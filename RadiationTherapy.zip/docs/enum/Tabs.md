# [RhythmBase](../../RhythmToolkit.md).[Events](../namespace/Events.md).Tabs
### [RhythmBase.dll](../assembly/RhythmBase.md)

- Song
- Rows
- Actions
- Sprites
- Rooms
- Unknown