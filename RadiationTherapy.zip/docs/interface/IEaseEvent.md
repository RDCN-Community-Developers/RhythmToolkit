# [RhythmBase](../namespaces.md).[Events](../namespace/Events.md).IEaseEvent
### [RhythmBase.dll](../assembly/RhythmBase.md)
缓动事件接口。

## 属性和字段

修饰 | 类型 | 名称 | 说明
-|-|-|-
| | [EaseType](../enum/EaseType.md) | Ease | 缓动类型
| | float | Duration | 缓动持续时间