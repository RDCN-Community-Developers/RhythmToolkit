## [返回](../RadiationTherapy.md)

# 介绍

本项目为节奏医生关卡开发者服务，旨在为开发人员提供更加系统、直观的关卡编辑媒介，与 7th Beat Games 工作室，Indienova 无从属关系。  

项目语言:  

C Sharp, Visual Basic

项目依赖:  

- Newtonsoft.Json
- SkiaSharp
- NAudio

感谢节奏医生饭制部玩家对这个项目的支持。