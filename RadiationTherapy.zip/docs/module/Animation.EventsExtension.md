# [RhythmBase](../../RhythmToolkit.md).[Extensions](../namespace/Extensions.md).AssetExtension
### [RhythmBase.Animation.dll](../assembly/RhythmAnimation.md)
动画扩展。

## 方法
修饰 | 类型 | 名称 | 说明
-|-|-|-
| | [EaseMovement][Mv] | GetAnimation([Move]() e) | 返回 [Move]() 事件的动画属性。<br>此方法为扩展方法。
| | [EaseMovement][Mv] | GetAnimation([MoveRow]() e) | 返回 [MoveRow]() 事件的动画属性。<br>此方法为扩展方法。
| | float | GetExpValue(Exp e, [Variables](../class/Variables.md) variables) | 返回 [Exp](../class/Exp.md) 的实际值。<br>此方法为扩展方法。

[Mv]: ../class/EaseMovement.md