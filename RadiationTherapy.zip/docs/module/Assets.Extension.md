# [RhythmBase](../../RhythmToolkit.md).[Extensions](../namespace/Extensions.md).AssetExtension
### [RhythmBase.Asset.dll](../assembly/RhythmAsset.md)
素材解析扩展。

## 方法
修饰 | 类型 | 名称 | 说明
-|-|-|-
| | [ISprite](../interface/ISprite.md) | Read([Quote](../class/Quote.md) p) | 返回一个新的 [ISprite](../interface/ISprite.md) 实例，用于承载扩展类型。<br>此方法为扩展方法。