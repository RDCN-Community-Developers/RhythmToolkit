# [RhythmBase](../../RhythmToolkit.md).[Utils](../namespace/Utils.md).ImageUtils
### [RhythmBase.Asset.dll](../assembly/RhythmAsset.md)
图像处理模块。

## 方法
修饰 | 类型 | 名称 | 说明
-|-|-|-
| | | Save(SKBitmap image, FileInfo path) | 保存为图像文件。<br>此方法为扩展方法。
| | SKBitmap | OutGlow(SKBitmap image, float sigma) | 返回图像经外发光处理后的新实例。<br>此方法为扩展方法。
| | SKBitmap | OutLine(SKBitmap image, float width) | 返回图像经描边处理后的新实例。(未完成)<br>此方法为扩展方法。  