# [RhythmBase](../namespaces.md).[Components].Ease
### [RhythmBase.dll](../assembly/RhythmBase.md)

## 枚举
- [EaseType](../enum/EaseType.md)

## 方法

修饰 | 类型 | 名称 | 说明
-|-|-|-
| |float | Calculate([EaseType](../enum/EaseType.md) Type, float x) | 返回缓动的值。<br>此方法为扩展方法。
| |float | Calculate([EaseType](../enum/EaseType.md) Type, float from, float to) | 返回缓动的值。<br>此方法为扩展方法。