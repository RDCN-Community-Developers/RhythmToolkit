# [RhythmBase](../../RhythmToolkit.md).[Extensions](../namespace/Extensions.md).Extension
### [RhythmBase.dll](../assembly/RhythmBase.md)

## 方法
修饰 | 类型 | 名称 | 说明
-|-|-|-
| | string | UpperCamelCase(string e) | 返回字符串的大驼峰命名副本。<br>此方法为扩展方法。
| | string | LowerCamelCase(string e) | 返回字符串的小驼峰命名副本。<br>此方法为扩展方法。
| | int | RgbaToArgb(int Rgba) | 返回十六进制颜色值的 Alpha 值前置副本。<br>此方法为扩展方法。
| | int | ArgbToRgba(int Argb) | 返回十六进制颜色值的 Alpha 值后置副本。<br>此方法为扩展方法。
| | float | FixFraction(float number, uint splitBase) | 返回浮点数的浮点吸附矫正副本。<br>此方法为扩展方法。