# [RhythmBase](../namespaces.md).Animation

## 类型

- [EaseValueGroup\<T\>](../class/Animation.EaseValueGroup_T_.md)
- [EaseValueCalculator](../class/Animation.EaseValueCalculator_T_.md)