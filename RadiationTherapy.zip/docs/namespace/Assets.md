# [RhythmBase](../namespaces.md).Assets

## 枚举

- [LoopOption](../enum/Assets.LoopOption.md)

## 类型

- [Sprite](../class/Sprite.md)