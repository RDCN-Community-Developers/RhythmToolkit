# [RhythmBase](../namespaces.md).[LevelElements](../namespace/LevelElements.md).Conditions 

## 类型
- [Custom](../class/.Custom.md)
- [Language](../class/Language.md)
- [LastHit](../class/LastHit.md)
- [PlayerMode](../class/PlayerMode.md)
- [TimesExecuted](../class/TimesExecuted.md)