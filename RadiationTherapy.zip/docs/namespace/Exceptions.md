# [RhythmBase](../namespaces.md).Exceptions

## 类型

- [ExpressionException](../class/ExpressionException.md)
- [RhythmBaseException](../class/RhythmBaseException.md)
- [ModuleException](../class/ModuleException.md)
- [FileExtensionMismatchException](../class/FileExtensionMismatchException.md)
- [OverwriteNotAllowedException](../class/OverwriteNotAllowedException.md)
- [SpriteException](../class/SpriteException.md)