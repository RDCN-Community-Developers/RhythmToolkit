# [RhythmHospital](../namespaces.md).Physicians

## 类型

- [Edega](../class/Edega.md)