# [RhythmBase](../namespaces.md).Settings

## 类型

- [LevelInputSettings](../class/LevelInputSettings.md)
- [LevelOutputSettings](../class/LevelOutputSettings.md)
- [SpriteInputSettings](../class/SpriteInputSettings.md)
- [SpriteOutputSettings](../class/SpriteOutputSettings.md)