## [返回](../RadiationTherapy.md)

# 命名空间

命名空间路径 | 命名空间主要内容
-|-
[RhythmBase.Animation](namespace/Animation.md) | 动画信息
[RhythmBase.Assets](namespace/Assets.md) | 素材辅助
[RhythmBase.Components](namespace/Components.md) | 关卡组件
[RhythmBase.Events](namespace/Events.md) | 关卡事件
[RhythmBase.Exceptions](namespace/Exceptions.md) | 内部异常
[RhythmBase.Extensions](namespace/Extensions.md) | 扩展
[RhythmBase.LevelElements](namespace/LevelElements.md) | 关卡元素
[RhythmBase.Settings](namespace/Settings.md) | 配置
[RhythmBase.Utils](namespace/Utils.md) | 工具
[RhythmHospital.Physicians](namespace/Physicians.md) | 辅助检查