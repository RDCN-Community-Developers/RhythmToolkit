using System.Drawing.Configuration;
using System.Security.Cryptography.X509Certificates;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private List<Point> ls = new List<Point>();
        private bool Recording = false;
        private void Record_Start()
        {
            Recording = true;
            ls.Clear();
            listBox1.Items.Clear();
            timer1.Interval = (int)(1000 / numericUpDown1.Value);
            timer1.Start();
            pictureBox1.Image = new Bitmap(352, 198);
        }

        private void Record_Stop()
        {
            Recording = false;
            timer1.Stop();
        }

        private void Record_Toggle()
        {
            if (Recording) Record_Stop();
            else Record_Start();
        }

        private void Draw_All()
        {
            Bitmap img = new Bitmap(352, 198);
            var g = Graphics.FromImage(img);
            var pen = new Pen(Color.Black, 1);
            foreach (var item in ls)
                g.DrawEllipse(pen, item.X - 2, item.Y - 2, 4, 4);
            for (var i = 1; i < ls.Count; i++)
                g.DrawLine(pen, ls[i - 1].X, ls[i - 1].Y, ls[i].X, ls[i].Y);
            pictureBox1.Image = img;
            g.Dispose();
        }

        private void pictureBox1_MouseClick(object sender, MouseEventArgs e)
        {
            Console.WriteLine("CLICK!");
            Record_Toggle();
        }

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            Record_Stop();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            var p = pictureBox1.PointToClient(Cursor.Position);
            // var cx = pictureBox1.Location.X;
            // var cy = pictureBox1.Location.Y;
            ls.Add(p);
            listBox1.Items.Add($"{p.X}, {p.Y}");
            listBox1.TopIndex = listBox1.Items.Count - (int)listBox1.Height / listBox1.ItemHeight;
            Draw_All();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var result = openFileDialog1.ShowDialog(this);
            if (result != DialogResult.OK) return;
            var path = openFileDialog1.FileName;
            var interval = (1000 / numericUpDown1.Value) / (60000 / numericUpDown2.Value);
            Work.Export(path, ls, (float)numericUpDown3.Value, (float)interval);
        }
    }
}
