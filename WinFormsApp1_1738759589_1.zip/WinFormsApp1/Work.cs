﻿using RhythmBase.Components;
using RhythmBase.LevelElements;
using RhythmBase.Assets;
using EaseT = RhythmBase.Components.Ease.EaseType;

namespace WinFormsApp1
{
    internal class Work
    {
        public static List<Tuple<int, int, EaseT>> Fit(List<int> ls, float tolerance)
        {
            List<EaseT> Easings = (from EaseT x in Enum.GetValues(typeof(EaseT)) select x).ToList();
            EaseT[] blacklist = [EaseT.SmoothStep, EaseT.Unset, EaseT.InBounce, EaseT.OutBounce, EaseT.InOutBounce,
                                 EaseT.InBack, EaseT.OutBack, EaseT.InOutBack, EaseT.InElastic, EaseT.OutElastic,
                                 EaseT.InOutElastic, EaseT.Linear];
            foreach (var e in blacklist)
                Easings.Remove(e);
            Easings.Insert(0, EaseT.Linear);
            // steps, start, easing, back
            var f = new List<Tuple<int, int, EaseT, int>>(ls.Count) { new (0, -1, EaseT.Unset, -1) };
            for (int i = 1; i < ls.Count; ++i)
            {
                f.Add(new Tuple<int, int, EaseT, int>(0, -1, EaseT.Unset, -1));
                for (int j = i - 1; j >= 0; --j)
                {
                    float bestDiff = float.PositiveInfinity;
                    foreach (EaseT e in Easings)
                    {
                        float diff = 0;
                        for (int k = 1; k + j < i; ++k)
                        {
                            diff = Math.Max(diff, Math.Abs(ls[j+k] - e.Calculate((float)k / (i - j), ls[j], ls[i])));
                            if (diff > tolerance) break;
                        }
                        if (diff < bestDiff && diff < tolerance)
                        {
                            f[i] = new(f[j].Item1 + 1, j, e, j);
                            bestDiff = diff;
                        }
                    }
                }
            }
            // start, end, easing
            var rvl = new List<Tuple<int, int, EaseT>>();
            for (int i = ls.Count - 1; i > 0; i = f[i].Item4)
            {
                rvl.Add(new Tuple<int, int, EaseT>(f[i].Item2, i, f[i].Item3));
            }
            rvl.Reverse();
            return rvl;
        }

        public static void Export(string path, List<Point> ls, float tolerance, float interval)
        {
            if (!Path.Exists(path)) return;
            var level = RDLevel.LoadFile(path);
            var lx = Fit((from x in ls select x.X).ToList(), tolerance);
            var deco = level.CreateDecoration(new Rooms(0), new Sprite());
            var e = deco.CreateChildren<RhythmBase.Events.Move>(1);
            e.BeatOnly = 1;
            e.Position = new NumOrExpPair((ls[0].X/352f*100).ToString(), ((198-ls[0].Y)/198f*100).ToString());
            e.Duration = 0;
            level.Add(e);
            foreach (var x in lx)
            {
                e = deco.CreateChildren<RhythmBase.Events.Move>((x.Item1 + 1) * interval + 1);
                e.Position = new NumOrExpPair((ls[x.Item2].X/352f*100).ToString(), "");
                e.Duration = (x.Item2 - x.Item1) * interval;
                e.Ease = x.Item3;
                level.Add(e);
            }
            lx = Fit((from x in ls select 198-x.Y).ToList(), tolerance);
            foreach (var x in lx)
            {
                e = deco.CreateChildren<RhythmBase.Events.Move>((x.Item1 + 1) * interval + 1);
                e.Position = new NumOrExpPair("", ((198-ls[x.Item2].Y)/198f*100).ToString());
                e.Duration = (x.Item2 - x.Item1) * interval;
                e.Ease = x.Item3;
                level.Add(e);
            }
            level.SaveFile(Path.Combine(Path.GetDirectoryName(path), Path.GetFileNameWithoutExtension(path)+"_out.rdlevel"));
        }
    }
}
